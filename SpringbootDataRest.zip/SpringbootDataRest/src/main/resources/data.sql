insert into alien values(1,'chaitanya','java');
insert into alien values(2,'jhon snow','sql');
insert into alien values(3,'otis','python');
insert into alien values(4,'meave','cloud');
insert into alien values(5,'tarun balaji','sql');